# handlers/saas.py
import asyncio
import logging
import os
from datetime import datetime, timedelta, timezone

from aiogram import Router, F, Bot
from aiogram.types import (
    CallbackQuery, Message, LabeledPrice,
    InlineKeyboardMarkup, InlineKeyboardButton,
    WebAppInfo
)
from aiogram.enums import ParseMode
from aiogram.fsm.context import FSMContext

from states import SaasStates, PaymentFSM
from services.db import get_db
from services.saas_core import publish_post_with_fallback
from services.admitad import fetch_admitad_catalog_for_user, ADULT_STORES, get_delivery_for_store, STORE_ID_MAP
from keyboards.saas import kb_cabinet_menu
from services.text_rewriter import generate_post_text
from services.admitad import get_random_promocode
from states import SaasStates, PaymentFSM, PayoutStates, TaxStates
from helpers import generate_success_text, show_user_cabinet
from config import MIN_PAYOUT, ADMIN_IDS, WEBAPP_ADMIN_URL
from keyboards.saas import open_saas_settings

logger = logging.getLogger("autopost_bot.saas")

router = Router(name="saas")

# ---------------------------------------------------------------------------
# Магазины
# ---------------------------------------------------------------------------
@router.callback_query(F.data == "menu:categories")
async def cb_stores(callback: CallbackQuery):
    user_id = callback.from_user.id
    conn = get_db()
    try:
        # Получаем выбранные пользователем магазины
        user_stores = conn.execute(
            "SELECT category_id FROM user_category_preferences WHERE user_id = ?",
            (user_id,)
        ).fetchall()
        user_store_ids = {r["category_id"] for r in user_stores}
        selected_count = len(user_store_ids)
        
        # Получаем список всех доступных магазинов
        from services.admitad import STORE_ID_MAP, get_available_stores
        available_stores = get_available_stores()
        
        stores = []
        for store_id, store_name in STORE_ID_MAP.items():
            store_info = available_stores.get(store_name, {})
            stores.append({
                "id": store_id,
                "name": store_name,
                "available": store_info.get("available", False),
                "adult": store_info.get("adult", False),
                "requires_city": store_name == "Galaxy Store"
            })
    finally:
        conn.close()

    text = f"🏪 <b>Выберите магазины для постинга:</b> (выбрано {selected_count})\n\n"
    kb_rows = []
    for store in stores:
        emoji = "✅" if store["id"] in user_store_ids else "❌"
        kb_rows.append([InlineKeyboardButton(
            text=f"{emoji} {store['name']}",
            callback_data=f"store_toggle:{store['id']}"
        )])
    kb_rows.append([InlineKeyboardButton(text="🔙 Назад", callback_data="cabinet:open")])
    kb = InlineKeyboardMarkup(inline_keyboard=kb_rows)
    await callback.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    await callback.answer()

@router.callback_query(F.data.startswith("store_toggle:"))
async def cb_toggle_store(callback: CallbackQuery):
    store_id = int(callback.data.split(":")[1])
    user_id = callback.from_user.id

    from services.admitad import STORE_ID_MAP, get_available_stores
    store_name = STORE_ID_MAP.get(store_id)
    if not store_name:
        await callback.answer("❌ Магазин не найден", show_alert=True)
        return

    store_info = get_available_stores().get(store_name, {})
    
    # Проверка доступности магазина
    if not store_info.get("available", False):
        await callback.answer(f"❌ {store_name} временно недоступен", show_alert=True)
        return

    # Для Galaxy Store проверяем выбор города
    if store_name == "Galaxy Store":
        conn = get_db()
        try:
            existing = conn.execute(
                "SELECT city FROM user_category_preferences WHERE user_id = ? AND category_id = 12",
                (user_id,)
            ).fetchone()
        finally:
            conn.close()
        if not existing or not existing["city"]:
            await show_city_selection(callback.message, user_id)
            await callback.answer()
            return

    conn = get_db()
    try:
        existing = conn.execute(
            "SELECT 1 FROM user_category_preferences WHERE user_id = ? AND category_id = ?",
            (user_id, store_id)
        ).fetchone()
        if existing:
            conn.execute(
                "DELETE FROM user_category_preferences WHERE user_id = ? AND category_id = ?",
                (user_id, store_id)
            )
        else:
            # ДЛЯ ВСЕХ ПОЛЬЗОВАТЕЛЕЙ БЕЗ ОГРАНИЧЕНИЙ — просто добавляем
            conn.execute(
                "INSERT INTO user_category_preferences (user_id, category_id) VALUES (?, ?)",
                (user_id, store_id)
            )
        conn.commit()
    finally:
        conn.close()

    from services.admitad import fetch_admitad_catalog_for_user
    try:
        await fetch_admitad_catalog_for_user(user_id, max_items_per_store=50)
        await callback.answer(f"🔄 Каталог {store_name} обновлён")
    except Exception as e:
        logger.error(f"Ошибка обновления каталога для {user_id}: {e}")
        await callback.answer("⚠️ Ошибка обновления каталога. Попробуйте позже.", show_alert=True)
    
    await cb_stores(callback)
    await callback.answer()

@router.callback_query(F.data == "promo:activate")
async def cb_promo_activate(callback: CallbackQuery, state: FSMContext):
    await callback.message.answer(
        "🎁 Введите промокод (просто отправьте код, без команды /promo):"
    )
    await state.set_state(SaasStates.waiting_promocode)
    await callback.answer()

@router.message(SaasStates.waiting_promocode)
async def process_promocode_input(message: Message, state: FSMContext):
    code = message.text.strip().upper()
    logger.info(f"[PROMO] Пользователь {message.from_user.id} ввёл код через кнопку: {code}")

    conn = get_db()
    try:
        # Ищем промокод без учёта регистра (приводим оба к верхнему)
        promo = conn.execute(
            "SELECT * FROM promocodes WHERE UPPER(code) = ?", (code,)
        ).fetchone()
        if not promo:
            await message.answer("❌ Неверный или несуществующий промокод.")
            await state.clear()
            return

        activation = conn.execute(
            "SELECT * FROM promocode_activations WHERE UPPER(code) = ?", (code,)
        ).fetchone()
        if activation:
            await message.answer("❌ Этот промокод уже использован.")
            await state.clear()
            return

        channels = conn.execute(
            "SELECT channel_id, channel_title FROM channels WHERE user_id = ? AND is_active = 1",
            (message.from_user.id,)
        ).fetchall()
    finally:
        conn.close()

    if not channels:
        await message.answer("❌ У вас нет подключённых каналов.")
        await state.clear()
        return

    days = int(promo["days"])

    if len(channels) == 1:
        channel_id = channels[0]["channel_id"]
        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO promocode_activations (code, user_id, channel_id) VALUES (?, ?, ?)",
                (promo["code"], message.from_user.id, channel_id)  # сохраняем оригинальный код
            )
            new_until = datetime.now(timezone.utc) + timedelta(days=days)
            conn.execute(
                "UPDATE users SET subscription_until = ?, is_active = 1 WHERE user_id = ?",
                (new_until.isoformat(), message.from_user.id)
            )
            conn.commit()
        finally:
            conn.close()
        await message.answer(f"✅ Промокод активирован!\nПодписка продлена на {days} дней.")
    else:
        # Несколько каналов – выбор (аналогично /promo)
        await state.update_data(promocode=promo["code"], promo_days=days)
        kb_rows = []
        for ch in channels:
            kb_rows.append([InlineKeyboardButton(
                text=ch["channel_title"] or ch["channel_id"],
                callback_data=f"promo_channel:{ch['channel_id']}"
            )])
        kb_rows.append([InlineKeyboardButton(text="🔙 Отмена", callback_data="cabinet:open")])
        await message.answer(
            "🎯 Выберите канал для активации промокода:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows)
        )

    await state.clear()

@router.callback_query(F.data == "share_success")
async def cb_share_success(callback: CallbackQuery):
    user_id = callback.from_user.id
    conn = get_db()
    try:
        role = conn.execute("SELECT role FROM users WHERE user_id=?", (user_id,)).fetchone()["role"]
    finally:
        conn.close()
    text = await generate_success_text(user_id, role)
    await callback.message.answer(text, parse_mode=ParseMode.HTML)
    await callback.answer("✅ Текст скопирован в следующее сообщение. Можете переслать его!", show_alert=True)
# ---------------------------------------------------------------------------
# Galaxy Store – выбор города
# ---------------------------------------------------------------------------
# Заглушка для CITY_DATA, если модуль catalog отсутствует
try:
    from catalog import CITY_DATA, get_city_name
except ImportError:
    # Если модуля нет, используем пустые данные, чтобы бот не падал
    CITY_DATA = {}
    def get_city_name(key):
        return key

async def show_city_selection(message: Message, user_id: int):
    if not CITY_DATA:
        await message.answer("Модуль выбора города временно недоступен.")
        return
    buttons = []
    for key, (rus_name, _) in CITY_DATA.items():
        buttons.append(InlineKeyboardButton(
            text=rus_name,
            callback_data=f"galaxy_city:{key}"
        ))
    rows = [buttons[i:i+2] for i in range(0, len(buttons), 2)]
    rows.append([InlineKeyboardButton(text="🔙 Отмена", callback_data="cancel_galaxy_city")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    await message.edit_text(
        "🏙 <b>Выберите ваш город для Galaxy Store:</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=markup
    )


@router.callback_query(F.data.startswith("galaxy_city:"))
async def cb_galaxy_city_selected(callback: CallbackQuery):
    city_key = callback.data.split(":")[1]
    user_id = callback.from_user.id
    city_name = get_city_name(city_key)

    conn = get_db()
    try:
        user_row = conn.execute("SELECT role FROM users WHERE user_id=?", (user_id,)).fetchone()
        is_blogger_or_saas = user_row and user_row["role"] in ("blogger", "saas")

        existing = conn.execute(
            "SELECT 1 FROM user_category_preferences WHERE user_id = ? AND category_id = 12",
            (user_id,)
        ).fetchone()
        if existing:
            conn.execute(
                "UPDATE user_category_preferences SET city = ? WHERE user_id = ? AND category_id = 12",
                (city_key, user_id)
            )
        else:
            conn.execute(
                "INSERT INTO user_category_preferences (user_id, category_id, city) VALUES (?, ?, ?)",
                (user_id, 12, city_key)
            )
        conn.commit()
    finally:
        conn.close()

    from services.admitad import fetch_admitad_catalog_for_user
    await fetch_admitad_catalog_for_user(user_id, max_items_per_store=50)
    
    await callback.answer(f"✅ Galaxy Store ({city_name}) добавлен в ваши магазины.")
    await cb_stores(callback)


@router.callback_query(F.data == "cancel_galaxy_city")
async def cb_cancel_galaxy_city(callback: CallbackQuery):
    await cb_stores(callback)
    await callback.answer()


# ---------------------------------------------------------------------------
# Force Post (единая логика)
# ---------------------------------------------------------------------------
import sqlite3

@router.callback_query(F.data == "saas_force_post")
async def cb_saas_force_post(callback: CallbackQuery, bot: Bot) -> None:
    """Обработчик кнопки принудительной публикации с улучшенной обработкой ошибок"""
    user_id = callback.from_user.id
    logger.info(f"User {user_id} triggered force post")
    
    conn = get_db()
    try:
        # Проверяем настройки пользователя
        user = conn.execute(
            "SELECT force_preview_confirmed FROM users WHERE user_id = ?", 
            (user_id,)
        ).fetchone()
        preview_confirmed = bool(user["force_preview_confirmed"]) if user else False
        
        # Проверяем наличие каналов
        channels_count = conn.execute(
            "SELECT COUNT(*) FROM channels WHERE user_id = ? AND is_active = 1",
            (user_id,)
        ).fetchone()[0]
        
        if channels_count == 0:
            await callback.answer("❌ Нет активных каналов", show_alert=True)
            return
            
        # Проверяем наличие товаров в каталоге
        product_count = conn.execute(
            "SELECT COUNT(*) FROM gdeslon_catalog WHERE user_id = ? AND used = 0 AND erid != '' AND erid IS NOT NULL",
            (user_id,)
        ).fetchone()[0]
        
        if product_count == 0:
            await callback.answer("❌ Нет доступных товаров для публикации", show_alert=True)
            return
            
    except sqlite3.Error as e:
        logger.error(f"Database error in cb_saas_force_post for user {user_id}: {e}")
        await callback.answer("⚠️ Ошибка базы данных", show_alert=True)
        return
    finally:
        conn.close()

    if preview_confirmed:
        logger.info(f"User {user_id} force posting immediately (preview confirmed)")
        await callback.answer("🚀 Публикую пост...", show_alert=True)
        await _force_post_immediate(callback, bot, user_id)
    else:
        logger.info(f"User {user_id} force posting with preview")
        await callback.answer("🔍 Подбираю товар для предпросмотра...", show_alert=False)
        await _force_post_preview(callback, bot, user_id)


async def _force_post_immediate(callback: CallbackQuery, bot: Bot, user_id: int, channel_id: str = None) -> None:
    """Публикация поста сразу без предпросмотра"""
    conn = get_db()
    try:
        # Получаем настройки пользователя
        user_stores = conn.execute(
            "SELECT category_id FROM user_category_preferences WHERE user_id = ?", 
            (user_id,)
        ).fetchall()
        store_ids = [r["category_id"] for r in user_stores]
        
        user_tmpl = conn.execute(
            "SELECT product_template FROM users WHERE user_id = ?", 
            (user_id,)
        ).fetchone()
        custom_template = user_tmpl["product_template"] if user_tmpl else None
        
        min_disc = conn.execute(
            "SELECT min_discount FROM users WHERE user_id = ?", 
            (user_id,)
        ).fetchone()
        min_discount = min_disc["min_discount"] if min_disc else 0
        
        # Получаем список каналов
        channels = conn.execute(
            "SELECT channel_id, channel_title FROM channels WHERE user_id = ? AND is_active = 1",
            (user_id,)
        ).fetchall()
        
        if not channels:
            await callback.answer("❌ Нет активных каналов", show_alert=True)
            return
            
        # Если канал не выбран, но их несколько - предлагаем выбор
        if not channel_id and len(channels) > 1:
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(
                    text=ch["channel_title"] or ch["channel_id"], 
                    callback_data=f"force_channel:{ch['channel_id']}"
                )] for ch in channels
            ])
            await callback.message.answer(
                "📢 Выберите канал для публикации:",
                reply_markup=kb
            )
            await callback.answer()
            return
    finally:
        conn.close()

    allowed_sources = [STORE_ID_MAP[sid] for sid in store_ids if sid in STORE_ID_MAP]

    conn = get_db()
    try:
        if allowed_sources:
            placeholders = ','.join('?' * len(allowed_sources))
            product = conn.execute(
                f"""SELECT * FROM gdeslon_catalog 
                WHERE user_id = ? AND used = 0 
                AND erid != '' AND erid IS NOT NULL 
                AND source IN ({placeholders}) 
                AND (discount_percent IS NULL OR discount_percent >= ?)
                ORDER BY 
                    CASE WHEN discount_percent >= 30 THEN 0  -- Приоритет товарам со скидкой 30%+
                    ELSE 1 END,
                    RANDOM()
                LIMIT 1""",
                (user_id, *allowed_sources, min_discount)
            ).fetchone()
        else:
            product = None

        if not product:
            if allowed_sources:
                conn.execute(
                    f"UPDATE gdeslon_catalog SET used = 0 WHERE user_id = ? AND source IN ({placeholders})",
                    (user_id, *allowed_sources)
                )
                conn.commit()
                product = conn.execute(
                    f"SELECT * FROM gdeslon_catalog WHERE user_id = ? AND erid != '' AND erid IS NOT NULL AND source IN ({placeholders}) AND (discount_percent IS NULL OR discount_percent >= ?) ORDER BY RANDOM() LIMIT 1",
                    (user_id, *allowed_sources, min_discount)
                ).fetchone()
            else:
                product = conn.execute(
                    "SELECT * FROM gdeslon_catalog WHERE user_id = ? AND used = 0 AND erid != '' AND erid IS NOT NULL AND (discount_percent IS NULL OR discount_percent >= ?) ORDER BY RANDOM() LIMIT 1",
                    (user_id, min_discount)
                ).fetchone()
                if not product:
                    conn.execute("UPDATE gdeslon_catalog SET used = 0 WHERE user_id = ?", (user_id,))
                    conn.commit()
                    product = conn.execute(
                        "SELECT * FROM gdeslon_catalog WHERE user_id = ? AND erid != '' AND erid IS NOT NULL AND (discount_percent IS NULL OR discount_percent >= ?) ORDER BY RANDOM() LIMIT 1",
                        (user_id, min_discount)
                    ).fetchone()

        if product:
            conn.execute("UPDATE gdeslon_catalog SET used = 1 WHERE id = ?", (product["id"],))
            conn.commit()
    finally:
        conn.close()

    if not product:
        await callback.message.answer("❌ В каталоге пока нет товаров с маркировкой ERID.")
        return

    await _publish_product(callback, bot, user_id, product, custom_template)

async def _force_post_preview(callback: CallbackQuery, bot: Bot, user_id: int) -> None:
    conn = get_db()
    try:
        user_stores = conn.execute("SELECT category_id FROM user_category_preferences WHERE user_id = ?", (user_id,)).fetchall()
        store_ids = [r["category_id"] for r in user_stores]
        user_tmpl = conn.execute("SELECT product_template FROM users WHERE user_id = ?", (user_id,)).fetchone()
        custom_template = user_tmpl["product_template"] if user_tmpl and user_tmpl["product_template"] else None
        min_disc = conn.execute("SELECT min_discount FROM users WHERE user_id = ?", (user_id,)).fetchone()
        min_discount = min_disc["min_discount"] if min_disc else 0
    finally:
        conn.close()

    allowed_sources = [STORE_ID_MAP[sid] for sid in store_ids if sid in STORE_ID_MAP]

    conn = get_db()
    try:
        if allowed_sources:
            placeholders = ','.join('?' * len(allowed_sources))
            product = conn.execute(
                f"SELECT * FROM gdeslon_catalog WHERE user_id = ? AND used = 0 AND erid != '' AND erid IS NOT NULL AND source IN ({placeholders}) AND (discount_percent IS NULL OR discount_percent >= ?) ORDER BY RANDOM() LIMIT 1",
                (user_id, *allowed_sources, min_discount)
            ).fetchone()
        else:
            product = None

        if not product:
            if allowed_sources:
                conn.execute(
                    f"UPDATE gdeslon_catalog SET used = 0 WHERE user_id = ? AND source IN ({placeholders})",
                    (user_id, *allowed_sources)
                )
                conn.commit()
                product = conn.execute(
                    f"SELECT * FROM gdeslon_catalog WHERE user_id = ? AND erid != '' AND erid IS NOT NULL AND source IN ({placeholders}) AND (discount_percent IS NULL OR discount_percent >= ?) ORDER BY RANDOM() LIMIT 1",
                    (user_id, *allowed_sources, min_discount)
                ).fetchone()
            else:
                product = conn.execute(
                    "SELECT * FROM gdeslon_catalog WHERE user_id = ? AND used = 0 AND erid != '' AND erid IS NOT NULL AND (discount_percent IS NULL OR discount_percent >= ?) ORDER BY RANDOM() LIMIT 1",
                    (user_id, min_discount)
                ).fetchone()
                if not product:
                    conn.execute("UPDATE gdeslon_catalog SET used = 0 WHERE user_id = ?", (user_id,))
                    conn.commit()
                    product = conn.execute(
                        "SELECT * FROM gdeslon_catalog WHERE user_id = ? AND erid != '' AND erid IS NOT NULL AND (discount_percent IS NULL OR discount_percent >= ?) ORDER BY RANDOM() LIMIT 1",
                        (user_id, min_discount)
                    ).fetchone()
    finally:
        conn.close()

    if not product:
        await callback.message.answer("❌ В каталоге пока нет товаров с маркировкой ERID.")
        return

    # ... (далее идёт формирование caption и показ предпросмотра, без изменений)

    partner_url = product['partner_url'] or ''
    title = product['title'] or ''
    price = product['price'] or 0
    currency = product['currency'] or '₽'
    advertiser = product['advertiser'] or 'Рекламодатель'
    erid = product['erid'] or ''
    photo_url = product["image_url"]
    source = product["source"] if "source" in product.keys() else ""
    adult = source in ADULT_STORES
    delivery_info = get_delivery_for_store(source)
    promocode = get_random_promocode(source)

    caption = generate_post_text(
        title=title,
        price=price,
        currency=currency,
        advertiser=advertiser,
        erid=erid,
        partner_url=partner_url,
        adult=adult,
        old_price=product["old_price"] if "old_price" in product.keys() else None,
        discount_percent=product["discount_percent"] if "discount_percent" in product.keys() else None,
        delivery_info=delivery_info,
        promocode=promocode,
        custom_template=custom_template
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Опубликовать", callback_data=f"force_confirm:{product['id']}")],
        [InlineKeyboardButton(text="❌ Отмена", callback_data=f"force_cancel:{product['id']}")],
    ])
    await callback.message.answer_photo(
        photo=photo_url,
        caption=caption,
        parse_mode=ParseMode.HTML,
        reply_markup=kb,
        has_spoiler=adult
    )


async def _publish_product(callback: CallbackQuery, bot: Bot, user_id: int, product, custom_template=None) -> None:
    partner_url = product['partner_url'] or ''
    title = product['title'] or ''
    price = product['price'] or 0
    currency = product['currency'] or '₽'
    advertiser = product['advertiser'] or 'Рекламодатель'
    erid = product['erid'] or ''
    photo_url = product["image_url"]
    source = product["source"] if "source" in product.keys() else ""

    conn = get_db()
    try:
        channels = conn.execute(
            "SELECT channel_id, sub_id FROM channels WHERE user_id = ? AND is_active = 1",
            (user_id,)
        ).fetchall()
    finally:
        conn.close()

    if not channels:
        await callback.message.answer("❌ У вас нет активных каналов.")
        return

    for ch in channels:
        final_url = partner_url
        if ch["sub_id"]:
            if '?' in final_url:
                final_url += '&subid=' + ch["sub_id"]
            else:
                final_url += '?subid=' + ch["sub_id"]
        # Добавляем subid2
        subid2 = generate_subid2(user_id, ch["channel_id"])
        if '?' in final_url:
            final_url += '&subid2=' + subid2
        else:
            final_url += '?subid2=' + subid2

        adult = source in ADULT_STORES
        delivery_info = get_delivery_for_store(source)
        promocode = get_random_promocode(source)

        caption = generate_post_text(
            title=title, price=price, currency=currency,
            advertiser=advertiser, erid=erid, partner_url=final_url,
            adult=adult,
            old_price=product["old_price"] if "old_price" in product.keys() else None,
            discount_percent=product["discount_percent"] if "discount_percent" in product.keys() else None,
            delivery_info=delivery_info, promocode=promocode,
            custom_template=custom_template
        )

        msg = await publish_post_with_fallback(
            bot=bot, channel_id=ch["channel_id"],
            caption=caption, photo_url=photo_url, has_spoiler=adult
        )
        if msg:
            direct_link = f"https://t.me/{ch['channel_id'].lstrip('@')}/{msg.message_id}"
            donor_post_id = f"admitad_{product['id']}_{user_id}_{int(datetime.now(timezone.utc).timestamp())}"
            conn_rec = get_db()
            try:
                conn_rec.execute(
                    """INSERT INTO posts 
                    (user_id, donor_post_id, channel_id, target_channel_id, subid1, subid2, direct_link, erid, status, published_at, caption)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'published', ?, ?)""",
                    (user_id, donor_post_id, ch['channel_id'], ch['channel_id'], ch['sub_id'], subid2, direct_link, erid,
                     datetime.now(timezone.utc).isoformat(), caption)
                )
                conn_rec.commit()
            finally:
                conn_rec.close()

            # ===== АВТО-ЗАКРЕПЛЕНИЕ (если включено у пользователя) =====
            from services.saas_core import pin_post_if_enabled
            await pin_post_if_enabled(bot, user_id, ch["channel_id"], msg.message_id)

        await asyncio.sleep(1)

@router.callback_query(F.data.startswith("force_channel:"))
async def cb_force_channel_select(callback: CallbackQuery, bot: Bot):
    """Обработчик выбора канала для принудительной публикации"""
    channel_id = callback.data.split(":")[1]
    await _force_post_immediate(callback, bot, callback.from_user.id, channel_id)
    await callback.message.delete()
    await callback.answer()

@router.callback_query(F.data.startswith("force_confirm:"))
async def cb_force_confirm(callback: CallbackQuery, bot: Bot) -> None:
    """Подтверждение публикации с предпросмотром"""
    product_id = int(callback.data.split(":")[1])
    user_id = callback.from_user.id

    conn = get_db()
    try:
        # Получаем товар
        product = conn.execute(
            "SELECT * FROM gdeslon_catalog WHERE id = ? AND user_id = ?", 
            (product_id, user_id)
        ).fetchone()
        if not product:
            await callback.answer("❌ Товар не найден", show_alert=True)
            return
            
        if product["used"] == 1:
            await callback.answer("⚠️ Этот товар уже публиковался", show_alert=True)
            await callback.message.delete()
            return

        # Помечаем как использованный
        conn.execute(
            "UPDATE gdeslon_catalog SET used = 1 WHERE id = ?", 
            (product_id,)
        )
        conn.commit()
        
        # Получаем каналы пользователя
        channels = conn.execute(
            "SELECT channel_id, sub_id FROM channels WHERE user_id = ? AND is_active = 1",
            (user_id,)
        ).fetchall()
    finally:
        conn.close()

    if not channels:
        await callback.answer("❌ Нет активных каналов", show_alert=True)
        return
        
    # Логируем действие
    logger.info(f"User {user_id} force-publishing product {product_id} to {len(channels)} channels")

    partner_url = product['partner_url'] or ''
    title = product['title'] or ''
    price = product['price'] or 0
    currency = product['currency'] or '₽'
    advertiser = product['advertiser'] or 'Рекламодатель'
    erid = product['erid'] or ''
    photo_url = product["image_url"]
    source = product["source"] if "source" in product.keys() else ""
    adult = source in ADULT_STORES
    delivery_info = get_delivery_for_store(source)
    promocode = get_random_promocode(source)

    conn = get_db()
    try:
        user_tmpl = conn.execute("SELECT product_template FROM users WHERE user_id = ?", (user_id,)).fetchone()
        custom_template = user_tmpl["product_template"] if user_tmpl and user_tmpl["product_template"] else None
    finally:
        conn.close()

    for ch in channels:
        final_url = partner_url
        if ch["sub_id"]:
            if '?' in final_url:
                final_url += '&subid=' + ch["sub_id"]
            else:
                final_url += '?subid=' + ch["sub_id"]
        # Добавляем subid2 для детализации трафика
        subid2 = generate_subid2(user_id, ch["channel_id"])
        if '?' in final_url:
            final_url += '&subid2=' + subid2
        else:
            final_url += '?subid2=' + subid2

        caption = generate_post_text(
            title=title,
            price=price,
            currency=currency,
            advertiser=advertiser,
            erid=erid,
            partner_url=final_url,
            adult=adult,
            old_price=product["old_price"] if "old_price" in product.keys() else None,
            discount_percent=product["discount_percent"] if "discount_percent" in product.keys() else None,
            delivery_info=delivery_info,
            promocode=promocode,
            custom_template=custom_template
        )

        msg = await publish_post_with_fallback(
            bot=bot,
            channel_id=ch["channel_id"],
            caption=caption,
            photo_url=photo_url,
            has_spoiler=adult
        )
        if msg:
            direct_link = f"https://t.me/{ch['channel_id'].lstrip('@')}/{msg.message_id}" if ch['channel_id'] else ""
            donor_post_id = f"admitad_{product['id']}_{user_id}_{int(datetime.now(timezone.utc).timestamp())}"
            conn_rec = get_db()
            try:
                conn_rec.execute(
                    """INSERT INTO posts 
                    (user_id, donor_post_id, channel_id, target_channel_id, subid1, subid2, direct_link, erid, status, published_at, caption)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'published', ?, ?)""",
                    (user_id, donor_post_id, ch['channel_id'], ch['channel_id'], ch['sub_id'], subid2, direct_link, erid,
                     datetime.now(timezone.utc).isoformat(), caption)
                )
                conn_rec.commit()
            finally:
                conn_rec.close()
        await asyncio.sleep(1)

    await callback.message.delete()
    await callback.message.answer("✅ Пост успешно опубликован!")
    await callback.answer()

@router.callback_query(F.data.startswith("force_cancel:"))
async def cb_force_cancel(callback: CallbackQuery) -> None:
    # Товар не трогаем, он остаётся used=0
    await callback.message.delete()
    await callback.message.answer("🚫 Публикация отменена.")
    await callback.answer()
# ---------------------------------------------------------------------------
# Настройка источника товаров (заглушка)
# ---------------------------------------------------------------------------
@router.callback_query(F.data == "saas_set:gdeslon_apikey")
async def cb_saas_set_source(callback: CallbackQuery) -> None:
    text = (
        "📦 <b>Источник товаров: Admitad</b>\n\n"
        "Бот автоматически загружает товары из выбранных вами магазинов-партнёров "
        "(Читай-город, KANZLER, SELA, Hi Store и других).\n"
        "Все товары поступают с готовой маркировкой ERID — дополнительных действий не требуется.\n\n"
        "Вы управляете ассортиментом через раздел «🏪 Магазины» в кабинете."
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Назад в настройки", callback_data="menu:settings")]
    ])
    await callback.message.edit_text(text, reply_markup=kb, parse_mode=ParseMode.HTML)
    await callback.answer()


# ---------------------------------------------------------------------------
# Промокоды
# ---------------------------------------------------------------------------
@router.callback_query(F.data.startswith("promo_channel:"))
async def promo_channel_selected(callback: CallbackQuery, state: FSMContext):
    channel_id = callback.data.split(":")[1]
    data = await state.get_data()
    code = data.get("promocode")
    days = data.get("promo_days", 2)

    if not code or not days:
        await callback.answer("❌ Сессия истекла, попробуйте снова.", show_alert=True)
        return

    conn = get_db()
    try:
        existing = conn.execute("SELECT * FROM promocode_activations WHERE code = ?", (code,)).fetchone()
        if existing:
            await callback.message.answer("❌ Промокод уже использован.")
            await state.clear()
            return

        conn.execute(
            "INSERT INTO promocode_activations (code, user_id, channel_id) VALUES (?, ?, ?)",
            (code, callback.from_user.id, channel_id)
        )
        new_until = datetime.now(timezone.utc) + timedelta(days=days)
        conn.execute(
            "UPDATE users SET subscription_until = ?, is_active = 1 WHERE user_id = ?",
            (new_until.isoformat(), callback.from_user.id)
        )
        conn.commit()
    finally:
        conn.close()

    await callback.message.edit_text(
        f"✅ Промокод активирован!\nПодписка продлена на {days} дн. до {new_until.strftime('%d.%m.%Y %H:%M')} (UTC)."
    )
    await state.clear()
    await callback.answer("Готово!", show_alert=True)


# ---------------------------------------------------------------------------
# Фильтр минимальной скидки
# ---------------------------------------------------------------------------
@router.callback_query(F.data == "menu:discount_filter")
async def cb_discount_filter(callback: CallbackQuery):
    user_id = callback.from_user.id
    conn = get_db()
    try:
        user = conn.execute("SELECT min_discount FROM users WHERE user_id=?", (user_id,)).fetchone()
        min_discount = user["min_discount"] if user else 0
    finally:
        conn.close()

    text = f"🎯 <b>Фильтр минимальной скидки</b>\n\nТекущее значение: <b>{min_discount}%</b>\n\nТовары со скидкой ниже этого значения не будут публиковаться."

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Выключить", callback_data="discount_set:0"),
         InlineKeyboardButton(text="от 10%", callback_data="discount_set:10")],
        [InlineKeyboardButton(text="от 20%", callback_data="discount_set:20"),
         InlineKeyboardButton(text="от 30%", callback_data="discount_set:30")],
        [InlineKeyboardButton(text="от 50%", callback_data="discount_set:50")],
        [InlineKeyboardButton(text="🔙 Назад", callback_data="cabinet:open")]
    ])
    await callback.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    await callback.answer()


@router.callback_query(F.data.startswith("discount_set:"))
async def cb_discount_set(callback: CallbackQuery):
    percent = int(callback.data.split(":")[1])
    user_id = callback.from_user.id
    conn = get_db()
    try:
        conn.execute("UPDATE users SET min_discount=? WHERE user_id=?", (percent, user_id))
        conn.commit()
    finally:
        conn.close()
    await callback.answer(f"✅ Минимальная скидка установлена: {percent}%", show_alert=True)
    await cb_discount_filter(callback)



# ---------------------------------------------------------------------------
# Финансы (история транзакций)
# ---------------------------------------------------------------------------
@router.callback_query(F.data == "menu:finance")
async def cb_finance(callback: CallbackQuery):
    user_id = callback.from_user.id
    conn = get_db()
    try:
        user = conn.execute("SELECT role, balance_available, balance_pending FROM users WHERE user_id=?", (user_id,)).fetchone()
        if not user:
            await callback.answer("Пользователь не найден", show_alert=True)
            return
        available = user["balance_available"] or 0.0
        pending = user["balance_pending"] or 0.0
        role = user["role"]
        transactions = conn.execute("""
            SELECT admitad_id, payment_sum, currency, payment_status, order_id, action, time
            FROM admitad_transactions
            WHERE user_id = ?
            ORDER BY time DESC
            LIMIT 20
        """, (user_id,)).fetchall()

        # Проверка активной заявки на выплату
        active_request = conn.execute(
            "SELECT id, status FROM payout_requests WHERE user_id=? AND status IN ('processing','awaiting_receipt','receipt_uploaded') ORDER BY id DESC LIMIT 1",
            (user_id,)
        ).fetchone()
    finally:
        conn.close()

    disclaimer = (
        "⚠️ <b>Важная информация о начислениях:</b>\n"
        "• Деньги за заказы сначала попадают в <b>«В ожидании»</b>. "
        "Рекламодатели проверяют заказы на предмет возврата.\n"
        "• Средний срок подтверждения: от 30 до 60 дней (зависит от магазина).\n"
        "• Как только магазин подтверждает покупку, деньги переходят в <b>«Доступно к выводу»</b>.\n"
        "• Любые попытки накрутки, самовыкупов, спам-рассылок или рекламы на бренд запрещены. "
        "При обнаружении нарушений аккаунт блокируется без выплаты средств.\n"
        "• Вывод средств возможен при достижении порога <b>3000 ₽</b>.\n\n"
    )

    text = f"💰 <b>Финансы</b>\n\n" \
           f"💳 Доступно к выводу: <b>{available:.2f} ₽</b>\n" \
           f"⏳ В ожидании: <b>{pending:.2f} ₽</b>\n\n"

    if not transactions:
        text += "У вас пока нет заказов."
    else:
        text += "<b>Последние 20 транзакций:</b>\n"
        for t in transactions:
            status_emoji = {
                "pending": "⏳", "approved": "✅", "declined": "❌",
                "new": "🆕", "waiting": "⏳", "paid": "💳"
            }.get(t["payment_status"], "❓")
            date_str = ""
            if t["time"]:
                try:
                    dt = datetime.fromtimestamp(int(t["time"]), tz=timezone.utc)
                    date_str = dt.strftime("%d.%m.%Y %H:%M")
                except:
                    date_str = str(t["time"])
            text += (
                f"{status_emoji} <b>{t['payment_sum']} {t['currency']}</b> "
                f"(статус: {t['payment_status']})\n"
                f"   Заказ #{t['order_id'] or '—'}, действие: {t['action'] or '—'}, "
                f"ID: {t['admitad_id']}\n"
                f"   Дата: {date_str}\n\n"
            )

    full_text = disclaimer + text

    kb_buttons = []
    if active_request:
        req_id, req_status = active_request["id"], active_request["status"]
        if req_status == "awaiting_receipt":
            kb_buttons.append([InlineKeyboardButton(text="📤 Отправить чек", callback_data=f"receipt:upload:{req_id}")])
            kb_buttons.append([InlineKeyboardButton(text="ℹ️ Статус: ожидание чека", callback_data="none")])
        elif req_status == "receipt_uploaded":
            kb_buttons.append([InlineKeyboardButton(text="⏳ Чек отправлен, ожидайте подтверждения", callback_data="none")])
        else:
            kb_buttons.append([InlineKeyboardButton(text="⏳ Заявка обрабатывается", callback_data="none")])
    else:
        if available >= MIN_PAYOUT:
            kb_buttons.append([InlineKeyboardButton(text="💸 Запросить выплату", callback_data="payout:request")])
        else:
            kb_buttons.append([InlineKeyboardButton(text="❌ Недостаточно средств для вывода", callback_data="none")])
    kb_buttons.append([InlineKeyboardButton(text="📢 Поделиться успехом", callback_data="share_success")])
    kb_buttons.append([InlineKeyboardButton(text="🔙 Назад в кабинет", callback_data="cabinet:open")])

    try:
        await callback.message.edit_text(full_text, parse_mode=ParseMode.HTML,
                                          reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_buttons))
    except Exception:
        await callback.message.answer(full_text, parse_mode=ParseMode.HTML,
                                      reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_buttons))
    await callback.answer()
@router.callback_query(F.data.startswith("receipt:upload:"))
async def cb_receipt_upload(callback: CallbackQuery, state: FSMContext):
    request_id = int(callback.data.split(":")[2])
    user_id = callback.from_user.id
    # Проверим принадлежность заявки и статус
    conn = get_db()
    try:
        req = conn.execute("SELECT * FROM payout_requests WHERE id=? AND user_id=? AND status='awaiting_receipt'", 
                           (request_id, user_id)).fetchone()
        if not req:
            await callback.answer("❌ Заявка не найдена или не в статусе ожидания чека.", show_alert=True)
            return
    finally:
        conn.close()
    await callback.message.answer("📎 Прикрепите фото/скриншот чека из приложения «Мой налог».")
    await state.set_state(PayoutStates.waiting_for_receipt_photo)
    await state.update_data(payout_request_id=request_id)
    await callback.answer()

@router.message(PayoutStates.waiting_for_receipt_photo, F.photo)
async def process_receipt_photo(message: Message, state: FSMContext):
    user_id = message.from_user.id
    data = await state.get_data()
    request_id = data.get("payout_request_id")
    if not request_id:
        await message.answer("❌ Ошибка сессии. Попробуйте снова.")
        await state.clear()
        return

    # Получаем file_id фото
    photo = message.photo[-1]
    file_id = photo.file_id

    conn = get_db()
    try:
        # Обновляем статус заявки и сохраняем file_id (можно в отдельное поле, добавим receipt_photo)
        conn.execute("UPDATE payout_requests SET status='receipt_uploaded', receipt_photo=? WHERE id=?",
                     (file_id, request_id))
        conn.commit()
    finally:
        conn.close()

    # Уведомление админам
    for admin_id in ADMIN_IDS:
        try:
            await message.bot.send_photo(
                admin_id,
                photo=file_id,
                caption=f"🧾 Чек по заявке #{request_id} от пользователя {user_id}.\n"
                        f"Проверьте и подтвердите выплату в админке.",
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="🌐 Админка", web_app=WebAppInfo(url=WEBAPP_ADMIN_URL))]
                ])
            )
        except Exception as e:
            logger.error(f"Ошибка отправки чека админу {admin_id}: {e}")

    await message.answer("✅ Чек отправлен администратору. Ожидайте подтверждения.")
    await state.clear()
# ---------------------------------------------------------------------------
# Оферта
# ---------------------------------------------------------------------------
@router.callback_query(F.data == "menu:oferta")
async def cb_menu_oferta(callback: CallbackQuery):
    user_id = callback.from_user.id
    conn = get_db()
    try:
        user = conn.execute("SELECT role, oferta_accepted FROM users WHERE user_id=?", (user_id,)).fetchone()
        role = user["role"] if user else "blogger"
        accepted = bool(user["oferta_accepted"]) if user else False
    finally:
        conn.close()

    if role == "saas":
        text_oferta = (
            "📜 <b>Публичная оферта (SaaS-клиент)</b>\n\n"
            "Для использования сервиса необходимо принять условия Пользовательского соглашения.\n\n"
            "<b>ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ (ПУБЛИЧНАЯ ОФЕРТА)</b>\n"
            "<i>Последняя редакция: 15 июля 2026 года</i>\n\n"
            "Нажимая «Принимаю», вы соглашаетесь с условиями и даёте согласие на обработку персональных данных.\n\n"
            "<b>1. Термины</b>\n"
            "• Сервис – данный Telegram-бот (технологическая платформа).\n"
            "• CPA-сеть – партнёрская сеть Admitad.\n"
            "• SubID – уникальный цифровой идентификатор вашего канала.\n"
            "• Баланс – справочные данные о вознаграждении, не электронные деньги.\n\n"
            "<b>2. Предмет</b>\n"
            "Вы получаете бессрочный бесплатный доступ к SaaS-инструменту автопостинга товаров с партнёрскими ссылками. "
            "Доход от подтвержденных CPA-сетью заказов распределяется в пропорции: 70% – Пользователю, 30% – Сервису.\n\n"
            "<b>3. Учёт, трансфер средств и Налоги</b>\n"
            "• Единственный источник данных о заказах – CPA-сеть.\n"
            "• В ожидании – заказы на проверке у рекламодателя (30–90 дней).\n"
            "• Доступно к выводу – подтверждённые заказы, готовые к трансферу.\n"
            "• Трансфер средств производится по запросу. Для этого необходимо в веб-статистике нажать "
            "«💸 Запросить выплату» и указать реквизиты. Пользователь обязан иметь статус Самозанятого или ИП "
            "и самостоятельно уплачивать налоги со своей доли (70%). Сервис не является налоговым агентом Пользователя.\n\n"
            "<b>4. Маркировка рекламы (ФЗ №38)</b>\n"
            "• Сервис автоматически вшивает в посты токен (erid) и наименование рекламодателя из CPA-сети.\n"
            "• Пользователь (Рекламораспространитель) самостоятельно и в полном объеме несет ответственность за "
            "ежемесячную передачу статистики просмотров постов в ОРД через свой личный кабинет. "
            "Сервис является исключительно техническим инструментом и отчеты за Пользователя не сдает.\n\n"
            "<b>5. Запрещено</b>\n"
            "Спам, накрутка, самовыкупы, мотивированный трафик, брендовая реклама, размещение ссылок вне добавленных каналов. "
            "Запрещен контент, нарушающий Brand Safety (казино, пиратство, насилие). Нарушение – бан и обнуление баланса.\n\n"
            "<b>6. Ответственность</b>\n"
            "• Переводы ограничены суммами, реально полученными от CPA-сети по конкретному SubID Пользователя.\n"
            "• Администрация вправе заморозить операции по балансу на время проверки трафика со стороны CPA-сети (до 90 дней). "
            "Пользователь обязан предоставить фискальные чеки из приложения 'Мой Налог' за предыдущие периоды по первому требованию.\n\n"
            "<b>7. Реферальная программа</b>\n"
            "• Приглашая других пользователей по реферальной ссылке, вы получаете вознаграждение в размере "
            "10% от суммы чистого заработка привлеченного лица.\n"
            "• Реферальные начисления (10%) вычитаются из заработка приглашённого пользователя (его 70%) и перечисляются рефереру.\n\n"
            "<b>8. Персональные данные</b>\n"
            "Сервис обрабатывает следующие персональные данные Пользователя: Telegram ID, username, реквизиты для выплат, "
            "налоговый статус, статистику публикаций и транзакций. Данные используются исключительно для оказания услуг "
            "и выполнения требований законодательства. Принимая настоящую оферту, Пользователь даёт согласие на обработку "
            "своих персональных данных в соответствии с Федеральным законом №152-ФЗ «О персональных данных». "
            "Данные хранятся на серверах на территории Российской Федерации и не передаются третьим лицам, "
            "за исключением случаев, предусмотренных законом."
        )
    else:  # blogger
        text_oferta = (
            "📜 <b>Публичная оферта (Блогер / Партнер)</b>\n\n"
            "Для использования сервиса необходимо принять условия Пользовательского соглашения.\n\n"
            "<b>ПОЛЬЗОВАТЕЛЬСКОЕ СОГЛАШЕНИЕ (ПУБЛИЧНАЯ ОФЕРТА)</b>\n"
            "<i>Последняя редакция: 15 июля 2026 года</i>\n\n"
            "Нажимая «Принимаю», вы заключаете договор о совместном оказании рекламных услуг "
            "и даёте согласие на обработку персональных данных.\n\n"
            "<b>1. Термины</b>\n"
            "• Сервис – данный Telegram-бот.\n"
            "• CPA-сеть – партнёрская сеть Admitad.\n"
            "• SubID – уникальный цифровой ID вашего канала для учета продаж.\n"
            "• Баланс – справочные данные о доходе, не являются электронными деньгами.\n\n"
            "<b>2. Предмет и Финансовая модель</b>\n"
            "Вы получаете бесплатный доступ к автопостингу. Доход от подтвержденных CPA-сетью "
            "заказов распределяется в пропорции: 70% – Блогеру, 30% – Сервису.\n\n"
            "<b>3. Реферальная программа</b>\n"
            "• Приглашая блогеров по реферальной ссылке, вы получаете вознаграждение в размере "
            "10% от суммы чистого заработка привлеченного лица.\n"
            "• Реферальные начисления (10%) вычитаются из заработка приглашённого блогера (его 70%) и перечисляются рефереру "
            "по мере подтверждения заказов рекламодателями.\n\n"
            "<b>4. Учёт, трансфер средств и Налоги</b>\n"
            "• Единственный источник данных о заказах – статистика CPA-сети.\n"
            "• В ожидании – заказы на верификации у рекламодателя (30–90 дней).\n"
            "• Доступно к выводу – подтвержденные и фактически оплаченные заказы. Минимальная сумма: 3000 ₽.\n"
            "• Трансфер средств производится по запросу. Для этого необходимо в веб-статистике нажать "
            "«💸 Запросить выплату» и указать реквизиты. Блогер обязан самостоятельно "
            "декларировать доходы (иметь статус Самозанятого или ИП). Сервис не является "
            "налоговым агентом Блогера.\n\n"
            "<b>5. Маркировка рекламы (ФЗ №38)</b>\n"
            "• Сервис автоматически вшивает в посты токен (erid) и данные рекламодателя из CPA-сети.\n"
            "• Блогер самостоятельно несет полную юридическую ответственность за ежемесячное "
            "предоставление статистики просмотров постов в ОРД через свой личный кабинет. "
            "Сервис отчеты за Блогера не сдает.\n\n"
            "<b>6. Запрещенный трафик и Контент</b>\n"
            "Запрещены: спам, клик-фрод, самовыкупы, мотивированный трафик, брендовая реклама. "
            "Запрещен контент, нарушающий Brand Safety (казино, пиратство, насилие). "
            "Нарушение – блокировка и обнуление баланса.\n\n"
            "<b>7. Ответственность и Форс-мажор</b>\n"
            "• Трансферы ограничены суммами, реально поступившими на счет Сервиса по конкретному SubID Блогера.\n"
            "• При блокировке общего аккаунта в CPA-сети из-за фрода, операции замораживаются до разрешения спора. "
            "При подтверждении фрода баланс нарушителя аннулируется.\n"
            "• Блогер обязан предоставить фискальный чек из приложения 'Мой Налог' за полученный перевод "
            "в течение 24 часов, загрузив его в веб-статистике (кнопка «📤 Отправить чек»). "
            "В случае отказа Сервис вправе заблокировать аккаунт Блогера.\n\n"
            "<b>8. Персональные данные</b>\n"
            "Сервис обрабатывает следующие персональные данные Пользователя: Telegram ID, username, реквизиты для выплат, "
            "налоговый статус, статистику публикаций и транзакций. Данные используются исключительно для оказания услуг "
            "и выполнения требований законодательства. Принимая настоящую оферту, Пользователь даёт согласие на обработку "
            "своих персональных данных в соответствии с Федеральным законом №152-ФЗ «О персональных данных». "
            "Данные хранятся на серверах на территории Российской Федерации и не передаются третьим лицам, "
            "за исключением случаев, предусмотренных законом."
        )

    if not accepted:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ Принимаю", callback_data="oferta:accept")],
            [InlineKeyboardButton(text="🔙 Назад", callback_data="cabinet:open")]
        ])
    else:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Назад", callback_data="cabinet:open")]
        ])

    await callback.message.edit_text(text_oferta, parse_mode=ParseMode.HTML, reply_markup=kb)
    await callback.answer()

# handlers/saas.py — замените существующий @router.callback_query(F.data == "oferta:accept")
@router.callback_query(F.data == "oferta:accept")
async def cb_oferta_accept(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    conn = get_db()
    try:
        conn.execute("UPDATE users SET oferta_accepted=1 WHERE user_id=?", (user_id,))
        conn.commit()
        row = conn.execute("SELECT tax_status FROM users WHERE user_id=?", (user_id,)).fetchone()
        tax_status = row["tax_status"] if row else ""
    finally:
        conn.close()

    await callback.answer("✅ Вы приняли условия Оферты.", show_alert=False)

    if tax_status in ("business", "individual"):
        # Статус уже указан – просто возвращаемся в кабинет
        await show_user_cabinet(callback.message, user_id=user_id)
        return

    # Запрашиваем налоговый статус
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🧾 Я Самозанятый / ИП", callback_data="tax:business")],
        [InlineKeyboardButton(text="👤 Обычное физлицо", callback_data="tax:individual")],
    ])
    await callback.message.answer(
        "Для возможности вывода средств укажите ваш налоговый статус в РФ:",
        reply_markup=kb
    )
    await state.set_state(TaxStates.waiting_tax_status)

@router.callback_query(F.data == "saas_toggle:force_preview_reset")
async def cb_force_preview_reset(callback: CallbackQuery):
    user_id = callback.from_user.id
    conn = get_db()
    try:
        conn.execute("UPDATE users SET force_preview_confirmed = 0 WHERE user_id = ?", (user_id,))
        conn.commit()
    finally:
        conn.close()
    await callback.answer("🔍 Предпросмотр снова будет показываться перед публикацией.", show_alert=True)
    await open_saas_settings(callback)

@router.callback_query(F.data == "tax_status:change")
async def cb_change_tax_status(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    conn = get_db()
    try:
        user = conn.execute("SELECT tax_status FROM users WHERE user_id=?", (user_id,)).fetchone()
        current = user["tax_status"] if user else ""
    finally:
        conn.close()

    if current == "business":
        current_text = "🧾 Самозанятый / ИП"
    elif current == "individual":
        current_text = "👤 Физическое лицо"
    else:
        current_text = "не указан"

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🧾 Я Самозанятый / ИП", callback_data="tax:business")],
        [InlineKeyboardButton(text="👤 Обычное физлицо", callback_data="tax:individual")],
        [InlineKeyboardButton(text="🔙 Отмена", callback_data="cabinet:open")]
    ])
    await callback.message.edit_text(
        f"Ваш текущий налоговый статус: <b>{current_text}</b>\n\n"
        "Выберите новый статус:",
        parse_mode=ParseMode.HTML,
        reply_markup=kb
    )
    await state.set_state(TaxStates.waiting_tax_status)
    await callback.answer()

def generate_subid2(user_id: int, channel_id: str) -> str:
    clean_channel = channel_id.lstrip("@").replace(" ", "_")
    return f"u{user_id}_ch_{clean_channel[:20]}"
